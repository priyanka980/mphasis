This application demonstrates angular-translate.

It has a default language of English, with translations available for German.

It uses programmatic translations on the home page and template translations on the sign in page.

It has runtime language changes, controlled in the Language Service. 

It uses cookie storage to store the users language key, and is enabled to store the language over cross http requests.

